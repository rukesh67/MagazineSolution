﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Configuration;

namespace MagazineStoreApp
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("-----Calling the Api to get the token-------");
                string tokenEndpoint = "http://magazinestore.azurewebsites.net/api/token";
                string apiToken = GetTokenAsync(tokenEndpoint).GetAwaiter().GetResult();

                IMagazineStore magazineStore = MagazineStoreFactory.GetMagazineInstance("", apiToken);
                Console.WriteLine("----Posting the Answer-----");
                var answer = magazineStore.PostAnswer();
                Console.WriteLine(answer?.AnswerCorrect);
                
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.Read();
        }


        static async Task<string> GetTokenAsync(string path)
        {
            string token = "";
            using (HttpClient client = new HttpClient())
            {

                var response = await client.GetAsync(path);
                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsAsync<TokenResponse>();
                    token = content.Token;
                }

            }
            return token;

        }

    }

}
