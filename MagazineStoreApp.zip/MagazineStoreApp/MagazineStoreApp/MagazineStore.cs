﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Configuration;
using MagazineStoreApp.Models;

namespace MagazineStoreApp
{
    public class MagazineStore : IMagazineStore
    {
        private readonly ApiHelper<ApiMagazineResponse> _apiMagazinehelper;
        private readonly ApiHelper<ApiSubscriberResponse> _apiSubscriberhelper;
        private readonly string _token;
        private readonly ApiHelper<ApiResponseCategory> _apiCategoriesHelper;
        private readonly ApiHelper<ApiAnswerResponse> _apiAnswerResponse;
        private int _categoriesCount;
        public MagazineStore(string token)
        {
            _apiMagazinehelper = new ApiHelper<ApiMagazineResponse>();
            _apiSubscriberhelper = new ApiHelper<ApiSubscriberResponse>();
            _token = token;
            _apiCategoriesHelper = new ApiHelper<ApiResponseCategory>();
            _apiAnswerResponse = new ApiHelper<ApiAnswerResponse>();
        }

        public MagazineStore(string token, ApiHelper<ApiMagazineResponse> apiMagazineHelper, ApiHelper<ApiSubscriberResponse> apiSubscriberHelper, ApiHelper<ApiResponseCategory> apiCategoryHelper)
        {
            _apiMagazinehelper = apiMagazineHelper;
            _apiSubscriberhelper = apiSubscriberHelper;
            _token = token;
            _apiCategoriesHelper = apiCategoryHelper;
        }

        private List<string> GetCategories()
        {
            string categoryPath = ConfigurationManager.AppSettings["CategoriesPath"] + _token;

            var categories = _apiCategoriesHelper.GetResponse(_token, categoryPath).GetAwaiter().GetResult();
            _categoriesCount = categories.Data.Count;
            return categories.Data;
        }

        private List<Magazine> GetMagazines()
        {
            List<Magazine> magazines = new List<Magazine>();
            var categories = GetCategories();
            foreach (var item in categories)
            {
                var magazinePath = ConfigurationManager.AppSettings["MagazinePath"] + _token + "/" + item;
                var results = _apiMagazinehelper.GetResponse(_token, magazinePath).GetAwaiter().GetResult();
                magazines.AddRange(results.Data);
            }
            return magazines;
        }

        private List<Subscriber> GetSubscribers()
        {
            string subscribersPath = ConfigurationManager.AppSettings["SubscribersPath"] + _token;
            var results = _apiSubscriberhelper.GetResponse(_token, subscribersPath).GetAwaiter().GetResult();

            return results.Data;
        }

        public Answer GetAnswer()
        {
            var magazines = GetMagazines();
            var subscribers = GetSubscribers();

            Answer answer = new Answer
            {
                Subscribers = new List<string>()
            };

            foreach (var item in subscribers)
            {

                var st = (from m in item.MagazineIds
                          join t in magazines
                 on m equals t.Id
                          group t by t.Category
                       into g
                          select new { key = g.Key }).ToList();

                if (st.Count == _categoriesCount)
                    answer.Subscribers.Add(item.Id);
            }


            return answer;

        }

        public AnswerResponse PostAnswer()
        {
            Answer answer = GetAnswer();
            AnswerResponse answerResponse=null;
            string answerspath = ConfigurationManager.AppSettings["AnswersPath"] + _token;
            var taskResponse = _apiAnswerResponse.Post<Answer>(_token, answerspath, answer);
            var apiAnswerResponse = taskResponse.GetAwaiter().GetResult();
            answerResponse = apiAnswerResponse?.Data;
            return answerResponse;
            
        }
    }
}