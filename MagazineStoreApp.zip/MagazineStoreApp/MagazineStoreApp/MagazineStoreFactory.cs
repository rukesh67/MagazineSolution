﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStoreApp
{
    public class MagazineStoreFactory
    {
        public static IMagazineStore GetMagazineInstance(string value, string apiToken)
        {
            IMagazineStore magazineStore;
            switch (value)
            {
                default:
                    magazineStore = new MagazineStore(apiToken);
                    break;
            }

            return magazineStore;

        }
    }
}
