﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStoreApp
{
    public class Answer
    {
        public List<string> Subscribers { get; set; }
    }
}
