﻿using MagazineStoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MagazineStoreApp
{
    public class ApiHelper<T>
    {
        public async Task<T> GetResponse(string token, string path)
        {
            var results = default(T);
            using (HttpClient client = new HttpClient())
            {

                var response = await client.GetAsync(path);
                if (response.IsSuccessStatusCode)
                {
                    results = await response.Content.ReadAsAsync<T>();
                }

            }
            return results;

        }

        public async Task<T> Post<R>(string token, string path,R obj)
        {
            var results = default(T);
            using (HttpClient client = new HttpClient())
            {

                var response = await client.PostAsJsonAsync(path,obj);
                if (response.IsSuccessStatusCode)
                {
                    results = await response.Content.ReadAsAsync<T>();
                }

            }
            return results;

        }


    }

}
